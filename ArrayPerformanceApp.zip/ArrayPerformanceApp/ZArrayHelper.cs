﻿using System;
using System.Diagnostics;

namespace ArrayPerformanceApp
{
    // This is just a helper class so the main form doesn’t get too messy
    public static class ZArrayHelper
    {
        // This function creates an array of a given size and fills it with random numbers
        public static int[] GenerateRandomArray(int ZSize, out long ZFillTimeMs)
        {
            ZFillTimeMs = 0; // just to be safe and initialize it

            // We create a new array with the size the user gave us
            int[] ZArray = new int[ZSize];

            // This will give us different random numbers each time
            Random ZRand = new Random();

            // We start the stopwatch to measure the filling time
            Stopwatch ZTimer = new Stopwatch();
            ZTimer.Start();

            // Loop through the array and fill it with random numbers (0–10,000)
            for (int Zi = 0; Zi < ZSize; Zi++)
            {
                for (int Zj = 0; Zj < 100; Zj++) ZRand.Next(); // simulated delay
                ZArray[Zi] = ZRand.Next(0, 10001);                                                                        // 10001 is exclusive so 10000 is included but im adding it twice to add delay.
            }

            ZTimer.Stop();  // stop the timer when we’re done filling

            // Save the time in milliseconds so we can display it later
            ZFillTimeMs = (long)ZTimer.Elapsed.TotalMilliseconds;

            // Return the finished array
            return ZArray;
        }

        // This function sorts the array and measures how long it takes
        public static void SortArray(int[] ZArray, out double ZSortTimeMs)
        {
            ZSortTimeMs = 0;

            // Quick check: if the array is null or tiny, no sorting needed
            if (ZArray == null || ZArray.Length < 2)
            {
                ZSortTimeMs = 0;
                return;
            }

            // Start timing the sorting
            Stopwatch ZTimer = new Stopwatch();
            ZTimer.Start();

            // Use built-in .NET sort (super fast and efficient)
            Array.Sort(ZArray);

            ZTimer.Stop();  // done sorting

            // Save the time so we can show it in the GUI
            ZSortTimeMs = ZTimer.Elapsed.TotalMilliseconds;
        }
    }
}
