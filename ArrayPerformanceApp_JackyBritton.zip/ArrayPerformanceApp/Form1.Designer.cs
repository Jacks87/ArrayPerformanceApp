﻿namespace ArrayPerformanceApp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.ZInputTextBox = new System.Windows.Forms.TextBox();
            this.ZStartButton = new System.Windows.Forms.Button();
            this.ZFillTimeLabel = new System.Windows.Forms.Label();
            this.ZSortTimeLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(177, 84);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(208, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Enter array size (1 - 10,000):";
            // 
            // ZInputTextBox
            // 
            this.ZInputTextBox.Location = new System.Drawing.Point(423, 84);
            this.ZInputTextBox.Name = "ZInputTextBox";
            this.ZInputTextBox.Size = new System.Drawing.Size(145, 26);
            this.ZInputTextBox.TabIndex = 1;
            // 
            // ZStartButton
            // 
            this.ZStartButton.Location = new System.Drawing.Point(297, 187);
            this.ZStartButton.Name = "ZStartButton";
            this.ZStartButton.Size = new System.Drawing.Size(188, 61);
            this.ZStartButton.TabIndex = 2;
            this.ZStartButton.Text = "Generate and Sort";
            this.ZStartButton.UseVisualStyleBackColor = true;
            this.ZStartButton.Click += new System.EventHandler(this.ZStartButton_Click);
            // 
            // ZFillTimeLabel
            // 
            this.ZFillTimeLabel.AutoSize = true;
            this.ZFillTimeLabel.Location = new System.Drawing.Point(223, 262);
            this.ZFillTimeLabel.Name = "ZFillTimeLabel";
            this.ZFillTimeLabel.Size = new System.Drawing.Size(70, 20);
            this.ZFillTimeLabel.TabIndex = 3;
            this.ZFillTimeLabel.Text = "Fill Time:";
            // 
            // ZSortTimeLabel
            // 
            this.ZSortTimeLabel.AutoSize = true;
            this.ZSortTimeLabel.Location = new System.Drawing.Point(487, 262);
            this.ZSortTimeLabel.Name = "ZSortTimeLabel";
            this.ZSortTimeLabel.Size = new System.Drawing.Size(81, 20);
            this.ZSortTimeLabel.TabIndex = 4;
            this.ZSortTimeLabel.Text = "Sort Time:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.ZSortTimeLabel);
            this.Controls.Add(this.ZFillTimeLabel);
            this.Controls.Add(this.ZStartButton);
            this.Controls.Add(this.ZInputTextBox);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox ZInputTextBox;
        private System.Windows.Forms.Button ZStartButton;
        private System.Windows.Forms.Label ZFillTimeLabel;
        private System.Windows.Forms.Label ZSortTimeLabel;
    }
}

