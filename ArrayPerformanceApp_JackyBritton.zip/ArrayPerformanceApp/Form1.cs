﻿using System;
using System.Diagnostics;
using System.Windows.Forms;

namespace ArrayPerformanceApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent(); // This builds the UI when the form starts
        }

        // When the user clicks the button, this function runs
        private void ZStartButton_Click(object sender, EventArgs e)
        {
            // First, we make sure the user typed in a valid number
            if (!int.TryParse(ZInputTextBox.Text, out int ZArraySize))
            {
                // If it wasn't a number, show a message and stop
                MessageBox.Show("Hey! Please enter a valid number.");
                return;
            }

            // Now we check if that number is within the allowed range
            if (ZArraySize <= 0 || ZArraySize > 10000)
            {
                MessageBox.Show("Only numbers between 1 and 10,000 please!");
                return;
            }

            // Create the array and track how long it takes to fill it
            long ZFillTimeMs;
            int[] ZGeneratedArray = ZArrayHelper.GenerateRandomArray(ZArraySize, out ZFillTimeMs);

            // Now sort that array and track how long the sorting takes
            double ZSortTimeMs;
            ZArrayHelper.SortArray(ZGeneratedArray, out ZSortTimeMs);
            ZSortTimeLabel.Text = $"Sort Time: {ZSortTimeMs:F2} ms";

            // Show the results in the GUI
            ZFillTimeLabel.Text = $"Fill Time: {ZFillTimeMs} ms";
            ZSortTimeLabel.Text = $"Sort Time: {ZSortTimeMs} ms";
        }
    }
}
