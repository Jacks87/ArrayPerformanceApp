﻿using System;
using System.Windows.Forms;

namespace ArrayPerformanceApp
{
    static class Program
    {
        [STAThread]  // Required for Windows Forms to run properly
        static void Main()
        {
            // This makes the app look modern with visual styles
            Application.EnableVisualStyles();

            // This ensures text looks clean and consistent
            Application.SetCompatibleTextRenderingDefault(false);

            // This actually runs the app and shows Form1
            Application.Run(new Form1());
        }
    }
}
